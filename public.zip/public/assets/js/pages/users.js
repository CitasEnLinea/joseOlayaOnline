'use strict';
$(document).ready(function() {
    var table = $('#editable_table');aTable({
        dom: '<"text-xs-right"B><f>lr<"table-responsive"t>ip
    table.Dat',
        buttons: [
            'copy', 'csv', 'print'
        ]
    });
    var tabl
    tableWrapper.find(".dataTables_length select").select2({eWrapper = $("#editable_table_wrapper");
        showSearchInput: false //hide search box with special css class
    }); // initialize select2 dropdown
    $("#editable_table_wrapper .dt-buttons .btn").addClass('btn-secondary').removeClass('btn-default');

     $('#example1').DataTable( {

        "dom": "<'row'<'col-md-6 col-xs-12'l><'col-md-6 col-xs-12'f>r><'table-responsive't><'row'<'col-md-5 col-xs-12'i><'col-md-7 col-xs-12'p>>",
        "order": [[ 3, "desc" ]]
    } );
});
