$(function() {
    var data = document.getElementById("datosMesa").value;
    var salon = document.getElementById("id_salon").value;
    
    var idMesas = "";

    data = data.split(" ");

    if (data.length > 2) {
        data = data[2].split(",");
    }

    console.log(data);

    for (var i = 0; i < data.length; i++) {
        var token = $("#token").val();

        $.ajax({
            headers: {'X-CSRF-TOKEN':token},
            type: "POST",
            url : "cargarIDMesa",
            datatype:'json',
            data : {'data':data[i], 'salon':salon},
            success : function(resul){
                console.log(resul[0].id)

                var mesa = '<input type="hidden" name ="mesa[]" value="'+resul[0].id+'">';
                    

                $("#mesas").append(mesa);
            }

        });
    }

    

    
});