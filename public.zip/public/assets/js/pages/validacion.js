'use strict';
$(document).ready(function() {
    $('#clear').on('click', function() {
        $('#form-crear,  #form-crear1').bootstrapValidator("resetForm");
    });

    /*$('#form-crear1').bootstrapValidator({
        fields: {
            nombre: {
                validators: {
                    notEmpty: {
                        message: 'Introduzca el nombre de sucursal'
                    }
                }
            },
            departamento: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione departamento'
                    }
                }
            },
            provincia: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione provincia'
                    }
                }
            },
            distrito: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione distrito'
                    }
                }
            },
          
            direccion: {
                validators: {
                    notEmpty: {
                        message: 'Direccion es requerida'
                    }
                }
            }
        },
        submitHandler: function(form) {
            if ($('#form-crear1').valid()) {
                console.log("now we enable the submit button!");
            }
        }
    }).on('success.form.bv', function(e) {
        e.preventDefault();
        swal({
            title: "Success.",
            text: "Successfully Added",
            type: "success",
            allowOutsideClick: false
        }).then(function() {
            location.reload();
        });
    });*/

    $('#form-crear').bootstrapValidator({
        fields: {
            nombre: {
                validators: {
                    notEmpty: {
                        message: 'Introduzca el nombre de sucursal'
                    }
                }
            },
            departamento: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione departamento'
                    }
                }
            },
            provincia: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione provincia'
                    }
                }
            },
            distrito: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione distrito'
                    }
                }
            },
          
            direccion: {
                validators: {
                    notEmpty: {
                        message: 'Direccion es requerida'
                    }
                }
            }
        },
        submitHandler: function(form) {
            if ($('#form-crear').valid()) {
                console.log("now we enable the submit button!");
            }
        }
    });
});