$(function() {

    var num = $("#num").val();
    num= parseInt(num);

    for(var i =0; i<num;i++){
        var posx = $("#posx"+i).val();
        var posy = $("#posy"+i).val();
        var ancho = $("#ancho"+i).val();
        var alto = $("#alto"+i).val();
        moverMesas("mesita"+i,posx,posy,ancho,alto);
    }

    var img = document.getElementById("plano_salon").value;

    console.log(img);

    var divImg = document.getElementById("plano");

    //divImg.style.backgroundImage = 'url('+ img +')';
    //divImg.style.backgroundColor = 'blue';
    //divImg.style.background = img;
    divImg.style.background = 'url('+ img +') no-repeat';
     divImg.style.backgroundSize = "100% 100%";
        
});

function moverMesas(mesita,posx,posy,ancho,alto){
   
    var bloque=document.getElementById(mesita);

    var x= parseInt(x);
    var y= parseInt(y);
    var anc= parseInt(anc);
    var alt= parseInt(alt);

    x = posx;
    y = posy;
    anc = ancho;
    alt = alto;

    bloque.style.top=x*3+"%";
    bloque.style.left=y*3+"%";
    bloque.style.width=anc+"%";
    bloque.style.height=alt+"%";

}


function moverMesaInst(mesita,num){
    var posx = $("#posx"+num).val();
    var posy = $("#posy"+num).val();
    var ancho = $("#ancho"+num).val();
    var alto = $("#alto"+num).val();
    var bloque=document.getElementById(mesita);

    var x= parseInt(x);
    var y= parseInt(y);
    var anc= parseInt(anc);
    var alt= parseInt(alt);

    x = posx;
    y = posy;
    anc = ancho;
    alt = alto;

    bloque.style.top=x*3+"%";
    bloque.style.left=y*3+"%";
    bloque.style.width=anc+"%";
    bloque.style.height=alt+"%";
}

$(document).on("submit",".form_entrada",function(e){

//funcion para atrapar los formularios y enviar los datos

       e.preventDefault();

       console.log($("#imagen_plano").val());
        
        var formu = $(this);
        var quien = $(this).attr("id");
        var token = $("#token").val();

        console.log(formu.serialize());

        if(quien=="f_registrar_mesa"){ var varurl="registrar_mesa"; }
        if(quien=="f_registrar_plano"){ var varurl="registrar_plano"; }
        if(quien=="f_editar_mesa"){ var varurl="editar_mesa";}
   
          $.ajax({
                headers: {'X-CSRF-TOKEN':token},
                type: "POST",
                url : varurl,
                datatype:'json',
                data : formu.serialize(),
                success : function(resul){
                    //$("#"+divresul+"").html(resul);
                    location.reload();
                }

            });

});

    $(document).on('change','.sucursal',function(){
            // console.log("hmm its change");
            var id_suc=$(this).val();
            console.log(id_suc);
            var div=$(this).parent();
            var token = $("#token").val();

            var op=" ";

            $.ajax({
                headers: {'X-CSRF-TOKEN':token},
                type:'get',
                url:"cargarSalon",
                data:{'id':id_suc},
                success:function(data){
                    //console.log('success');

                    console.log(data);

                    //console.log(data.length);
                    op+='<option selected disabled>::Elija</option>';
                    for(var i=0;i<data.length;i++){
                    op+='<option value="'+data[i].id+'">'+data[i].descripcion+'</option>';
                   }

                   //console.log(op);

                   //div.find('.salon').html(" ");
                   $("#salon").html(" ");
                   //div.find('.salon').append(op);
                   $("#salon").append(op);
                },
                error:function(){

                }
            });
        });

    $(document).on('change','.salon',function(){
            // console.log("hmm its change");
            var id_sal=$(this).val();
            console.log(id_sal);
            var div=$(this).parent();
            var cant = 0;
            var mesas = " ";
            var dibujarMesas = " ";
            var token = $("#token").val();

            var op=" ";

            $.ajax({
                headers: {'X-CSRF-TOKEN':token},
                type:'get',
                url:"cargarMesas",
                data:{'id':id_sal},
                success:function(data){
                    //console.log('success');

                    console.log(data);

                   $("#tableMesas tbody").empty();
                   $("#dibujarMesas").empty();
           
            for(var i = 0; i < data.length; i++){
            
                  
                    mesas = mesas + '<tr role="row" class="even" id="cuadrito">'+
                            '<form id="f_editar_mesa" method="post" action="editar_mesa" class="form-horizontal form_entrada">'+    
                                '<input type="hidden" name="id_mesa" value="'+data[i].id+'">'+    
                                '<td>'+data[i].num+'</td>'+
                                '<td><input class="form-control" min="0" type="number" id="ancho'+cant+'" name="ancho" value="'+data[i].ancho+'" style="width:35px;" onchange="moverMesaInst("mesita'+cant+'",'+cant+');"></td>'+
                               '<td><input class="form-control" min="0" type="number" id="alto'+cant+'"'+ 
                                'name="alto" value="'+data[i].alto+'" style="width : 35px; " onchange="moverMesaInst("mesita'+cant+'",'+cant+');"></td>'+
                               '<td><input class="form-control" min="0" max="167" type="number" id="posx'+cant+'" name="posx" value="'+data[i].posx+'" style="width : 35px; " onchange="moverMesaInst("mesita'+cant+'",'+cant+');"></td>'+
                               '<td><input class="form-control" min="0" max="158" type="number" id="posy'+cant+'" name="posy" value="'+data[i].posy+'" style="width : 35px; " onchange="moverMesaInst("mesita'+cant+'",'+cant+');"></td>'+

                               '<td><button type="submit" class="btn btn-info">'+ 
                                '<i class="fa fa-floppy-o" aria-hidden="true"></i>'+
                               '</button></td>'+
                            '</form>'+
                        '</tr>';

                    dibujarMesas = dibujarMesas + '<button id="mesita'+cant+'" style="position:absolute;" class="btn btn-primary" type="submit" value="">'+
                    data[i].num+'</button>';

                    cant++;
                    
                
            }

            console.log(mesas);
            console.log(dibujarMesas);

            $("#tableMesas tbody").append(mesas);  
            $("#dibujarMesas").append(dibujarMesas);  

                },
                error:function(){

                }
            });
        });

    $(document).on('change','.form-salon',function(){

            var id_sal=$(this).val();
            console.log(id_sal);
            var div=$(this).parent();
            var token = $("#token").val();
            var webeo = " ";


            $.ajax({
                headers: {'X-CSRF-TOKEN':token},
                type:'get',
                url:"cargarPlano",
                data:{'id':id_sal},
                success:function(data){
                    //console.log('success');

                    console.log(data);

                    var img = ".." + data[0].imagen;

                    console.log(img);

                    var divImg = document.getElementById("plano");

                    //divImg.style.backgroundImage = 'url('+ img +')';
                    //divImg.style.backgroundColor = 'blue';
                    //divImg.style.background = img;
                    divImg.style.background = 'url('+ img +') no-repeat';
                     divImg.style.backgroundSize = "100% 100%";


             
                   /* mesas = mesas + '<tr role="row" class="even" id="cuadrito">'+
                            '<form id="f_editar_mesa" method="post" action="editar_mesa" class="form-horizontal form_entrada">'+    
                                '<input type="hidden" name="id_mesa" value="'+data[i].id+'">'+    
                                '<td>'+data[i].num+'</td>'+
                                '<td><input class="form-control" min="0" type="number" id="ancho'+cant+'" name="ancho" value="'+data[i].ancho+'" style="width:35px;" onchange="moverMesaInst("mesita'+cant+'",'+cant+');"></td>'+
                               '<td><input class="form-control" min="0" type="number" id="alto'+cant+'"'+ 
                                'name="alto" value="'+data[i].alto+'" style="width : 35px; " onchange="moverMesaInst("mesita'+cant+'",'+cant+');"></td>'+
                               '<td><input class="form-control" min="0" max="167" type="number" id="posx'+cant+'" name="posx" value="'+data[i].posx+'" style="width : 35px; " onchange="moverMesaInst("mesita'+cant+'",'+cant+');"></td>'+
                               '<td><input class="form-control" min="0" max="158" type="number" id="posy'+cant+'" name="posy" value="'+data[i].posy+'" style="width : 35px; " onchange="moverMesaInst("mesita'+cant+'",'+cant+');"></td>'+

                               '<td><button type="submit" class="btn btn-info">'+ 
                                '<i class="fa fa-floppy-o" aria-hidden="true"></i>'+
                               '</button></td>'+
                            '</form>'+
                        '</tr>';

                
            }*/

            //console.log(mesas);

            //$("#tableMesas tbody").append(mesas);  

                },
                error:function(){
                    console.log('error');
                }
            });

            // console.log("hmm its change");
            /*var img = document.getElementById("plano_salon").value;

            console.log(img);

            var divImg = document.getElementById("plano");

            //divImg.style.backgroundImage = 'url('+ img +')';
            //divImg.style.backgroundColor = 'blue';
            //divImg.style.background = img;
            divImg.style.background = 'url('+ img +') no-repeat';
            divImg.style.backgroundSize = "100% 100%";*/
    });
