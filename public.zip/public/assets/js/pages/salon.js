$(document).on("submit",".form_entrada",function(e){

//funcion para atrapar los formularios y enviar los datos

       e.preventDefault();

       //console.log("beba");
        
        var formu = $(this);
        var quien = $(this).attr("id");
        var token = $("#token").val();

        if(quien=="f_registrar_salon"){ var varurl="registrar_salon"; }
        if(quien=="f_editar_salon"){ var varurl="editar_salon";}

          $.ajax({
                headers: {'X-CSRF-TOKEN':token},
                type: "POST",
                url : varurl,
                datatype:'json',
                data : formu.serialize(),
                success : function(resul){
                    location.reload();
                }

            });

})

