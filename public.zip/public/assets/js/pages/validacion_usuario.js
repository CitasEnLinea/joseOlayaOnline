'use strict';
$(document).ready(function() {
    $('#clear').on('click', function() {
        $('#form-crear,  #form-crear1').bootstrapValidator("resetForm");
    });


    $('#form-crear').bootstrapValidator({
        fields: {
            id_empleado: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione el nombre del empleado'
                    }
                }
            },
            usuario: {
                validators: {
                    notEmpty: {
                        message: 'Ingrese un usuario'
                    }
                }
            },
            password: {
                validators: {
                    notEmpty: {
                        message: 'Ingrese una contraseña'
                    }
                }
            },
            cargo: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione cargo'
                    }
                }
            }
        },
        submitHandler: function(form) {
            if ($('#form-crear').valid()) {
                console.log("now we enable the submit button!");
            }
        }
    });
});