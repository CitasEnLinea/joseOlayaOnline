'use strict';
$(document).ready(function() {
    $('#clear').on('click', function() {
        $('#form-crear,  #form-crear1').bootstrapValidator("resetForm");
    });

    $('#form-crear').bootstrapValidator({
        fields: {
            nombre: {
                validators: {
                    notEmpty: {
                        message: 'Ingrese un nombre'
                    }
                }
            },
            precio: {
                validators: {
                    notEmpty: {
                        message: 'Ingrese un precio'
                    }
                }
            },
            id_categoria: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione categoria'
                    }
                }
            },
            id_destino: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione destino'
                    }
                }
            }
        },
        submitHandler: function(form) {
            if ($('#form-crear').valid()) {
                console.log("now we enable the submit button!");
            }
        }
    });
});