'use strict';

var opciones = {
		Lambayeque : ["Chiclayo","Lambayeque"],
		Lima : ["Ciudad1","Ciudad2"]
}

var opciones2 = {
		Chiclayo : ["Chiclayo","La Victoria","JLO"],
		Lambayeque : ["Distrito1","Distrito2","Distrito3"],
        Ciudad1: ["DistritoL1","DistritoL2","DistritoL3"],
        Ciudad2: ["DistritoL4","DistritoL5","DistritoL6"]
}
//$(document).ready(function()
$(function(){
	var fillProvincia = function(){
		var selected = $('#dpto').val();
		var selected2 = $('#prov').val();
		$('#prov').empty();
        $('#prov').append('<option selected disabled>Provincia</option>');
		opciones[selected].forEach(function(element,index){
			if(selected2 == element){
				$('#prov').append('<option selected value="'+element+'">'+element+'</option>');
			}else{
				$('#prov').append('<option value="'+element+'">'+element+'</option>');
			}
		});
	}
	$('#dpto').change(fillProvincia);
	fillProvincia();
     
});


var fillDistrito = function(){
		var selected = $('#prov').val();
		var selected2 = $('#dist').val();
		$('#dist').empty();
        $('#dist').append('<option selected disabled>Distrito</option>');
		opciones2[selected].forEach(function(element,index){
			if(selected2 == element){
				$('#dist').append('<option selected value="'+element+'">'+element+'</option>');
			}else{
				$('#dist').append('<option value="'+element+'">'+element+'</option>');
			}
		});
	}
	$('#prov').change(fillDistrito);
	fillDistrito();
