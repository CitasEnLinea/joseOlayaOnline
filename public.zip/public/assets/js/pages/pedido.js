$(function() {

    //$("#plano").hide();

    var num = $("#num").val();
    num= parseInt(num);

    for(var i =0; i<num;i++){
        var posx = $("#posx"+i).val();
        var posy = $("#posy"+i).val();
        var ancho = $("#ancho"+i).val();
        var alto = $("#alto"+i).val();
        moverMesas("mesita"+i,posx,posy,ancho,alto);
    }

    var img = document.getElementById("plano_salon").value;

    console.log(img);

    var divImg = document.getElementById("plano");

    //divImg.style.backgroundImage = 'url('+ img +')';
    //divImg.style.backgroundColor = 'blue';
    //divImg.style.background = img;
    divImg.style.background = 'url('+ img +') no-repeat';
     divImg.style.backgroundSize = "100% 100%";
        
});

function formatear(){

    ancho = document.even.txtAncho.value;
    alto= document.even.txtAlto.value;  
    posx = document.even.txtPosx.value;
    posy = document.even.TxtPoxy.value;
    cuadrito = document.getElementById('cuadrito');

    cuadrito.style.width=ancho;
    cuadrito.style.height=alto;
    cuadrito.style.top=posx;
    cuadrito.style.left=posy;
    cuadrito.innerHTML= document.getElementById('cuadrito');
}

function moverMesas(mesita,posx,posy,ancho,alto){
   
    var bloque=document.getElementById(mesita);

    var x= parseInt(x);
    var y= parseInt(y);
    var anc= parseInt(anc);
    var alt= parseInt(alt);

    x = posx;
    y = posy;
    anc = ancho;
    alt = alto;

    bloque.style.top=x*3+"px";
    bloque.style.left=y*3+"px";
    bloque.style.width=anc+"px";
    bloque.style.height=alt+"px";

}


function moverMesaInst(mesita,num){
    var posx = $("#posx"+num).val();
    var posy = $("#posy"+num).val();
    var ancho = $("#ancho"+num).val();
    var alto = $("#alto"+num).val();
    var bloque=document.getElementById(mesita);

    var x= parseInt(x);
    var y= parseInt(y);
    var anc= parseInt(anc);
    var alt= parseInt(alt);

    x = posx;
    y = posy;
    anc = ancho;
    alt = alto;

    bloque.style.top=x*3+"px";
    bloque.style.left=y*3+"px";
    bloque.style.width=anc+"px";
    bloque.style.height=alt+"px";
}

$(document).on("submit",".form_entrada",function(e){

//funcion para atrapar los formularios y enviar los datos

       e.preventDefault();

       console.log($("#imagen_plano").val());
        
        var formu = $(this);
        var quien = $(this).attr("id");
        var token = $("#token").val();

        console.log(formu.serialize());

        if(quien=="f_registrar_mesa"){ var varurl="registrar_mesa"; }
        if(quien=="f_registrar_plano"){ var varurl="registrar_plano"; }
        if(quien=="f_editar_mesa"){ var varurl="editar_mesa";}
   
          $.ajax({
                headers: {'X-CSRF-TOKEN':token},
                type: "POST",
                url : varurl,
                datatype:'json',
                data : formu.serialize(),
                success : function(resul){
                    //$("#"+divresul+"").html(resul);
                    location.reload();
                }

            });

});

   /* $(document).on('change','.sucursal',function(){
            // console.log("hmm its change");
            var id_suc=$(this).val();
            console.log(id_suc);
            var div=$(this).parent();
            var token = $("#token").val();

            var op=" ";

            $.ajax({
                headers: {'X-CSRF-TOKEN':token},
                type:'get',
                url:"cargarSalon",
                data:{'id':id_suc},
                success:function(data){
                    //console.log('success');

                    console.log(data);

                    //console.log(data.length);
                    op+='<option selected disabled>::Elija</option>';
                    for(var i=0;i<data.length;i++){
                    op+='<option value="'+data[i].id+'">'+data[i].descripcion+'</option>';
                   }

                   //console.log(op);

                   //div.find('.salon').html(" ");
                   $("#salon").html(" ");
                   //div.find('.salon').append(op);
                   $("#salon").append(op);
                },
                error:function(){

                }
            });
        });

    $(document).on('change','.salon',function(){
            // console.log("hmm its change");

            var id_sal=$(this).val();
            console.log(id_sal);
            var div=$(this).parent();
            var cant = 0;
            var mesas = " ";
            var dibujarMesas = " ";
            var token = $("#token").val();

            var op=" ";

            $.ajax({
                headers: {'X-CSRF-TOKEN':token},
                type:'get',
                url:"cargarMesas",
                data:{'id':id_sal},
                success:function(data){
                    //console.log('success');

                    console.log(data);

                   $("#tableMesas tbody").empty();
                   $("#dibujarMesas").empty();
           
            for(var i = 0; i < data.length; i++){
            
                  
                    mesas = mesas + '<tr role="row" class="even" id="cuadrito">'+
                            '<form id="f_editar_mesa" method="post" action="editar_mesa" class="form-horizontal form_entrada">'+    
                                '<input type="hidden" name="id_mesa" value="'+data[i].id+'">'+    
                                '<td>'+data[i].num+'</td>'+
                                '<td><input class="form-control" min="0" type="number" id="ancho'+cant+'" name="ancho" value="'+data[i].ancho+'" style="width:35px;" onchange="moverMesaInst("mesita'+cant+'",'+cant+');"></td>'+
                               '<td><input class="form-control" min="0" type="number" id="alto'+cant+'"'+ 
                                'name="alto" value="'+data[i].alto+'" style="width : 35px; " onchange="moverMesaInst("mesita'+cant+'",'+cant+');"></td>'+
                               '<td><input class="form-control" min="0" max="167" type="number" id="posx'+cant+'" name="posx" value="'+data[i].posx+'" style="width : 35px; " onchange="moverMesaInst("mesita'+cant+'",'+cant+');"></td>'+
                               '<td><input class="form-control" min="0" max="158" type="number" id="posy'+cant+'" name="posy" value="'+data[i].posy+'" style="width : 35px; " onchange="moverMesaInst("mesita'+cant+'",'+cant+');"></td>'+

                               '<td><button type="submit" class="btn btn-info">'+ 
                                '<i class="fa fa-floppy-o" aria-hidden="true"></i>'+
                               '</button></td>'+
                            '</form>'+
                        '</tr>';

                    dibujarMesas = dibujarMesas + '<button id="mesita'+cant+'" style="position:absolute;" class="btn btn-primary" type="submit" value="">'+
                    data[i].num+'</button>';

                    cant++;
                    
                
            }

            console.log(mesas);
            console.log(dibujarMesas);

            $("#tableMesas tbody").append(mesas);  
            $("#dibujarMesas").append(dibujarMesas);  


                },
                error:function(){

                }
            });
        });*/

    $(document).on('change','.form-salon',function(){

            //$("#plano").show();

            var id_sal=$(this).val();
            console.log(id_sal);
            var div=$(this).parent();
            var token = $("#token").val();
            var mesas = "";

            $("#capa_modal").show();
              $("#capa_para_edicion").show();
              var url = "verMesas/"+id_sal+""; 
              //$("#capa_para_edicion").html($("#cargador_empresa").html());
              $.get(url,function(resul){
                  $("#capa_para_edicion").html(resul);

                   var num = $("#num").val();
                    num= parseInt(num);
                    console.log(num);

    for(var i =0; i<num;i++){
        var posx = $("#posx"+i).val();
        var posy = $("#posy"+i).val();
        var ancho = $("#ancho"+i).val();
        var alto = $("#alto"+i).val();
        moverMesas("mesita"+i,posx,posy,ancho,alto);
    }

    var img = document.getElementById("plano_salon").value;

    console.log(img);

    var divImg = document.getElementById("plano");

    //divImg.style.backgroundImage = 'url('+ img +')';
    //divImg.style.backgroundColor = 'blue';
    //divImg.style.background = img;
    divImg.style.background = 'url('+ img +') no-repeat';
     divImg.style.backgroundSize = "100% 100%";
              })

           /* $.ajax({
                headers: {'X-CSRF-TOKEN':token},
                type:'get',
                url:"cargarPlano",
                data:{'id':id_sal},
                success:function(data){
                    //console.log('success');

                    $("#dibujarMesas").empty();

                    var img = ".." + data[0].imagen;

                    var divImg = document.getElementById("plano");

                    //divImg.style.backgroundImage = 'url('+ img +')';
                    //divImg.style.backgroundColor = 'blue';
                    //divImg.style.background = img;
                    divImg.style.background = 'url('+ img +') no-repeat';
                     divImg.style.backgroundSize = "100% 100%";


                     for(var i = 0; i < data.length; i++){
             
                   mesas = mesas + '<tr role="row" class="even" id="cuadrito">'+
                            '<form id="f_editar_mesa" method="post" action="editar_mesa" class="form-horizontal form_entrada">'+    
                                '<input type="hidden" name="id_mesa" value="'+data[i].id+'">'+    
                                '<td>'+data[i].num+'</td>'+
                                '<td><input class="form-control" min="0" type="number" id="ancho'+cant+'" name="ancho" value="'+data[i].ancho+'" style="width:35px;" onchange="moverMesaInst("mesita'+cant+'",'+cant+');"></td>'+
                               '<td><input class="form-control" min="0" type="number" id="alto'+cant+'"'+ 
                                'name="alto" value="'+data[i].alto+'" style="width : 35px; " onchange="moverMesaInst("mesita'+cant+'",'+cant+');"></td>'+
                               '<td><input class="form-control" min="0" max="167" type="number" id="posx'+cant+'" name="posx" value="'+data[i].posx+'" style="width : 35px; " onchange="moverMesaInst("mesita'+cant+'",'+cant+');"></td>'+
                               '<td><input class="form-control" min="0" max="158" type="number" id="posy'+cant+'" name="posy" value="'+data[i].posy+'" style="width : 35px; " onchange="moverMesaInst("mesita'+cant+'",'+cant+');"></td>'+

                               '<td><button type="submit" class="btn btn-info">'+ 
                                '<i class="fa fa-floppy-o" aria-hidden="true"></i>'+
                               '</button></td>'+
                            '</form>'+
                        '</tr>';

                        mesas = mesas + '<button id="mesita'+i+'" style="position:absolute;" class="btn btn-primary" type="submit" value="">'+data[i].num+'</button>'+
                        '<input type="hidden" id="ancho'+i+'" name="ancho" value="'+data[i].ancho+'">'+
                        '<input type="hidden" id="alto'+i+'" name="alto" value="'+data[i].alto+'">'+
                        '<input type="hidden" id="posx'+i+'" name="posx" value="'+data[i].posx+'">'+
                        '<input type="hidden" id="posy'+i+'" name="posy" value="'+data[i].posy+'">';


                
                    }

            document.getElementById("num").value = data.length;
            $("#dibujarMesas").append(mesas);  

            //$("#tableMesas tbody").append(mesas);

            var num = $("#num").val();
            num= parseInt(num);

            for(var i =0; i<num;i++){
                var posx = $("#posx"+i).val();
                var posy = $("#posy"+i).val();
                var ancho = $("#ancho"+i).val();
                var alto = $("#alto"+i).val();
                moverMesas("mesita"+i,posx,posy,ancho,alto);
            }

                },
                error:function(){
                    console.log('error');
                }
            });

            // console.log("hmm its change");
            /*var img = document.getElementById("plano_salon").value;

            console.log(img);

            var divImg = document.getElementById("plano");

            //divImg.style.backgroundImage = 'url('+ img +')';
            //divImg.style.backgroundColor = 'blue';
            //divImg.style.background = img;
            divImg.style.background = 'url('+ img +') no-repeat';
            divImg.style.backgroundSize = "100% 100%";*/
    });

$(document).on("click",".div_modal",function(e){
 //funcion para ocultar las capas modales
 $("#capa_modal").hide();
 $("#capa_para_edicion").hide();
 $("#capa_para_edicion").html("");

})  