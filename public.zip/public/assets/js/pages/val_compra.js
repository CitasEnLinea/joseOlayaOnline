'use strict';
$(document).ready(function() {
    $('#clear').on('click', function() {
        $('#form-crear,  #form-crear1').bootstrapValidator("resetForm");
    });

    $('#form-crear').bootstrapValidator({
        fields: {
            id_proveedor: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione proveedor'
                    }
                }
            },
            tipoRecibo: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione tipo de recibo'
                    }
                }
            }
        },
        submitHandler: function(form) {
            if ($('#form-crear').valid()) {
                console.log("now we enable the submit button!");
            }
        }
    });
});