$(function() {

    $("#MostrarMesas").hide();

    document.getElementById("datosMesa").value = "Mesas: ";

    var num = $("#num").val();
    num= parseInt(num);

    for(var i =0; i<num;i++){
        var posx = $("#posx"+i).val();
        var posy = $("#posy"+i).val();
        var ancho = $("#ancho"+i).val();
        var alto = $("#alto"+i).val();
        moverMesas("mesita"+i,posx,posy,ancho,alto);
    }

    var img = document.getElementById("plano_salon").value;

    console.log(img);

    var divImg = document.getElementById("plano");

    //divImg.style.backgroundImage = 'url('+ img +')';
    //divImg.style.backgroundColor = 'blue';
    //divImg.style.background = img;
    divImg.style.background = 'url('+ img +') no-repeat';
     divImg.style.backgroundSize = "100% 100%";
        
});

function moverMesas(mesita,posx,posy,ancho,alto){
   
    var bloque=document.getElementById(mesita);

    var x= parseInt(x);
    var y= parseInt(y);
    var anc= parseInt(anc);
    var alt= parseInt(alt);

    x = posx;
    y = posy;
    anc = ancho;
    alt = alto;

    bloque.style.top=x*3+"%";
    bloque.style.left=y*3+"%";
    bloque.style.width=anc+"%";
    bloque.style.height=alt+"%";

}

$(document).on("click",".orden",function(e){
    document.getElementById("datosMesa").value = "Mesas: ";
    $("#MostrarMesas").show();
});

$(document).on("click",".mesalibre",function(e){

    var id_mesa=$(this).val();
    console.log(id_mesa);
    var data = document.getElementById("datosMesa").value;
    console.log(data);
    var b = 0;

    data1 = data.split(" ");
    console.log(data1);


    if (data1.length == 2) {
        data = data + ' ' + id_mesa;
    }

    if (data1.length > 2) {
        data2 = data1[2].split(",");
        console.log(data2);

        for (var i = 0; i < data2.length; i++) {
            if (data2[i] == id_mesa) {
                b = 1;
            }
        }

        if (b == 0) {
            data = data + ',' + id_mesa;
        }
    }

    
    

    document.getElementById("datosMesa").value = data;
});
