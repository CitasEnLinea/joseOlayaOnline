'use strict';
$(document).ready(function() {
    $('#clear').on('click', function() {
        $('#form-crear,  #form-crear1').bootstrapValidator("resetForm");
    });

    $('#form-crear').bootstrapValidator({
        fields: {
            nombre: {
                validators: {
                    notEmpty: {
                        message: 'Introduzca nombre de insumo'
                    }
                }
            },
            unidad: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione unidad'
                    }
                }
            },
            id_categoria: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione categoria'
                    }
                }
            },
            medida: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione medida'
                    }
                }
            },
            cantidadxM: {
                validators: {
                    notEmpty: {
                        message: 'Introduzca cantidad por medida'
                    }
                }
            },
            stock_minimo: {
                validators: {
                    notEmpty: {
                        message: 'Introduzca un stock minimo'
                    }
                }
            },
            precio: {
                validators: {
                    notEmpty: {
                        message: 'Introduzca precio'
                    }
                }
            }
        },
        submitHandler: function(form) {
            if ($('#form-crear').valid()) {
                console.log("now we enable the submit button!");
            }
        }
    });
});