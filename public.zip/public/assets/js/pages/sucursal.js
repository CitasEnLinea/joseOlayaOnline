'use strict';
$(document).ready(function() {

     $('#example1').DataTable( {

        "dom": "<'row'<'col-md-6 col-xs-12'l><'col-md-6 col-xs-12'f>r><'table-responsive't><'row'<'col-md-5 col-xs-12'i><'col-md-7 col-xs-12'p>>",
        "order": [[ 0, "desc" ]]
    } );
});
