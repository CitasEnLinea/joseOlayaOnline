'use strict';
$(document).ready(function() {
    $('#clear').on('click', function() {
        $('#form-crear,  #form-crear1').bootstrapValidator("resetForm");
    });

    $('#form-crear').bootstrapValidator({
        fields: {
            dni: {
                validators: {
                    notEmpty: {
                        message: 'Introduzca el dni de empleado'
                    }
                }
            },
            nombres: {
                validators: {
                    notEmpty: {
                        message: 'Introduzca nombres'
                    }
                }
            },
            apellido_paterno: {
                validators: {
                    notEmpty: {
                        message: 'Introduzca apellido paterno'
                    }
                }
            },
            apellido_materno: {
                validators: {
                    notEmpty: {
                        message: 'Introduzca apellido materno'
                    }
                }
            }
        },
        submitHandler: function(form) {
            if ($('#form-crear').valid()) {
                console.log("now we enable the submit button!");
            }
        }
    });
});