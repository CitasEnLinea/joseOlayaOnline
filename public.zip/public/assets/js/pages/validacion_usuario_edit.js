'use strict';
$(document).ready(function() {
    $('#clear').on('click', function() {
        $('#form-crear,  #form-crear1').bootstrapValidator("resetForm");
    });


    $('#form-crear').bootstrapValidator({
        fields: {
            
            dni: {
                validators: {
                    notEmpty: {
                        message: 'Ingrese un dni'
                    }
                }
            },
            
            nombres: {
                validators: {
                    notEmpty: {
                        message: 'Ingrese nombres'
                    }
                }
            },
            
            apellido_paterno: {
                validators: {
                    notEmpty: {
                        message: 'Ingrese apellido paterno'
                    }
                }
            },
            
            apellido_materno: {
                validators: {
                    notEmpty: {
                        message: 'Ingrese apellido materno'
                    }
                }
            },
          
            usuario: {
                validators: {
                    notEmpty: {
                        message: 'Ingrese un usuario'
                    }
                }
            },
         
            cargo: {
                validators: {
                    notEmpty: {
                        message: 'Seleccione cargo'
                    }
                }
            }
        },
        submitHandler: function(form) {
            if ($('#form-crear').valid()) {
                console.log("now we enable the submit button!");
            }
        }
    });
});