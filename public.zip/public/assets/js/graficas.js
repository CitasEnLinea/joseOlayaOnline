
$(document).on('change','.categoria',function(){
            // console.log("hmm its change");
            var id_cat=$(this).val();
            console.log(id_cat);
            var div=$(this).parent();
            var token = $("#token").val();

            var op=" ";

            $.ajax({
                headers: {'X-CSRF-TOKEN':token},
                type:'get',
                url:"cargarProductos",
                data:{'id':id_cat},
                success:function(data){
                    //console.log('success');

                    console.log(data);

                    //console.log(data.length);
                    op+='<option selected disabled>Elija</option>';
                    for(var i=0;i<data.length;i++){
                    op+='<option value="'+data[i].id+'">'+data[i].nombre+'</option>';
                   }

                   //console.log(op);

                   //div.find('.salon').html(" ");
                   $("#productos").html(" ");
                   //div.find('.salon').append(op);
                   $("#productos").append(op);
                },
                error:function(){

                }
            });
        });

$(document).on('change','.producto',function(){
            // console.log("hmm its change");
            var id_pro=$(this).val();
            console.log(id_pro);

            cargar_grafica_pie_2(id_pro);

        });


function cargar_grafica_pie_2(id_pro){

var options={
     // Build the chart
     
            chart: {
                renderTo: 'div_grafica_pie_2',
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },
            title: {
                text: 'Grafica producto'
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: false
                    },
                    showInLegend: true
                }
            },
            credits:{
                enabled:false
            },
            series: [{
                name: 'Porcentaje',
                colorByPoint: true,
                data: []
            }]
     
}

$("#div_grafica_pie_2").html( $("#cargador_empresa").html() );

var url = "grafica_producto_insumo/"+id_pro+"";


$.get(url,function(resul){
var datos= jQuery.parseJSON(resul);
var insumos = datos.insumos;
var totalinsumos=datos.totalinsumos;

    for(i=0;i<=totalinsumos-1;i++){  
    var objeto= {name: insumos[i].nombre+" - "+insumos[i].cantidad+insumos[i].medida, y:insumos[i].cantidad };     
    options.series[0].data.push( objeto );  
    }
 //options.title.text="aqui e podria cambiar el titulo dinamicamente";
 chart = new Highcharts.Chart(options);

})

}

function cargar_grafica_barras_2(){

var options={
     chart: {
            renderTo: 'div_grafica_barras_2',
            type: 'column'
        },
        title: {
            text: 'Cantidad de Ventas'
        },
        xAxis: {
            categories: [],
             title: {
                text: 'Productos'
            },
            crosshair: true
        },
        yAxis: {
            min: 0,
            title: {
                text: 'VENTAS POR PRODUCTO'
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                '<td style="padding:0"><b>{point.y} </b></td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
         credits:{
            enabled:false
        },
        series: [{
            name: 'registros',
            data: []

        }]
}

//$("#div_grafica_barras").html($("#cargador_empresa").html());

var url = "grafica_registros_2";


$.get(url,function(resul){
var datos= jQuery.parseJSON(resul);
var cantidadProductos=datos.cantidadProductos;
var ventasProductos = datos.ventasProductos;
var productos = datos.productos;
var i=0;
    for(i=0;i<=cantidadProductos;i++){
    
    options.series[0].data.push( ventasProductos[i] );
    options.xAxis.categories.push(productos[i]);


    }

     //options.title.text="aqui e podria cambiar el titulo dinamicamente";
 chart = new Highcharts.Chart(options);
})
}
