$(document).ready(function(){
        $('#mostrarPaciente').click(function(){
            $('#nombrePaciente').val('holi')
        });

            
        
        });